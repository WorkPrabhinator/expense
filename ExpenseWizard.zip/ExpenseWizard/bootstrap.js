import 'dotenv/config';
import './dist/index.js';
