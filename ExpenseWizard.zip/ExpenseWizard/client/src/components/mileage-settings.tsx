import { useState } from "react";
import * as React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Settings, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function MileageSettings() {
  const [rate, setRate] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: currentRate, isLoading } = useQuery({
    queryKey: ['/api/mileage-rate'],
    queryFn: async () => {
      const response = await fetch('/api/mileage-rate', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth-token')}`
        }
      });
      if (!response.ok) throw new Error('Failed to fetch mileage rate');
      return response.json();
    }
  });

  // Update rate when data is loaded
  React.useEffect(() => {
    if (currentRate?.rate) {
      setRate(currentRate.rate.toString());
    }
  }, [currentRate]);

  const updateRateMutation = useMutation({
    mutationFn: async (newRate: number) => {
      const response = await fetch('/api/mileage-rate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth-token')}`
        },
        body: JSON.stringify({ rate: newRate })
      });
      if (!response.ok) throw new Error('Failed to update mileage rate');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mileage-rate'] });
      toast({
        title: "Success",
        description: "Mileage rate updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update mileage rate",
        variant: "destructive",
      });
    }
  });

  const handleSave = () => {
    const newRate = parseFloat(rate);
    if (isNaN(newRate) || newRate <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid rate",
        variant: "destructive",
      });
      return;
    }
    updateRateMutation.mutate(newRate);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Mileage Settings
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">Loading...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="w-5 h-5" />
          Mileage Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="mileageRate">Mileage Rate (per mile)</Label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500">$</span>
              <Input
                id="mileageRate"
                type="number"
                step="0.001"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
                placeholder="0.680"
                className="pl-8"
              />
            </div>
            <Button 
              onClick={handleSave}
              disabled={updateRateMutation.isPending}
              className="flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              {updateRateMutation.isPending ? "Saving..." : "Save"}
            </Button>
          </div>
        </div>
        
        <div className="text-sm text-slate-600 space-y-1">
          <p>Current rate: <span className="font-medium">${currentRate?.rate.toFixed(3)} per mile</span></p>
          <p className="text-xs">Standard Canadian rate: $0.680 per mile</p>
        </div>
      </CardContent>
    </Card>
  );
}