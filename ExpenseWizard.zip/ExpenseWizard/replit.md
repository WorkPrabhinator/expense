# ExpenseFlow - Internal Expense Tracker

## Overview

ExpenseFlow is a web-based expense tracking application designed to replace basic Expensify functionality for small agencies. The system allows employees to submit expense reports and enables managers to review and approve/reject submissions through a unified web interface. The application features both manual expense submission via web forms and automated processing through email and Google Forms integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **State Management**: Zustand for authentication state, React Query for server state
- **Routing**: Wouter for client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Session Management**: Simple in-memory session storage with bearer tokens
- **File Processing**: Built-in support for receipt file handling (images and PDFs)

### Database Schema
- **Users Table**: Stores employee information with roles (employee, approver, admin)
- **Expenses Table**: Comprehensive expense tracking with approval workflow states
- **System Settings**: Configuration storage for mileage rates and other system settings
- **Migration Support**: Drizzle Kit for schema migrations

### Authentication & Authorization
- **Authentication**: Simple email-based login with session tokens
- **Authorization**: Role-based access control (employee, approver, admin)
- **Session Storage**: In-memory sessions for development/demo purposes

### Key Features
- **Multi-submission Methods**: Web form, email processing, and Google Forms integration
- **Approval Workflow**: Three-state system (pending, approved, rejected) with approval notes
- **Receipt Management**: File upload and storage with support for images and PDFs
- **Mileage Tracking**: Specialized fields for mileage expenses with configurable rates
- **Real-time Notifications**: Email notifications for submission and approval events
- **Dashboard Analytics**: Statistics overview with expense status breakdowns

## External Dependencies

### Database
- **Neon Database**: PostgreSQL-compatible serverless database via @neondatabase/serverless
- **Connection Pooling**: Built-in connection pooling for database performance

### Google Services Integration
- **Gmail API**: Automated expense email processing from designated inbox
- **Google Drive**: Receipt file storage and sharing
- **Google Sheets**: Alternative data storage and backup option
- **Google Forms**: Alternative expense submission method

### Optional Services
- **Supabase**: Alternative backend-as-a-service option (client configured but not actively used)

### Development Tools
- **Replit Integration**: Cartographer plugin for Replit development environment
- **Runtime Error Handling**: Vite plugin for better error debugging
- **Hot Module Replacement**: Vite HMR for development workflow

### Email Notifications
- **Gmail SMTP**: Outbound notification system for approval/rejection alerts
- **Automated Workflows**: Configurable notification triggers for workflow events