# Expenser

An app for Foundationites to report their expenses.

## Running locally

- Ask a developer for a proper .env and insert it in this root directory
- Install nvm (e.g. via Homebrew on mac)
- Use node 20 and setup:

```bash
nvm install 20
echo "20" > .nvmrc
nvm use
npx update-browserslist-db@latest
```

- To run:

```bash
npm install; npm run dev
```

- Visit http://localhost:5001/

### Running the production build

```bash
npm run build; npm run start
```
