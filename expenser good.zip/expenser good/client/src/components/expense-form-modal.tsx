import { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { getAuthHeader } from "@/lib/auth";
import { insertExpenseSchema } from "@shared/schema";
import { z } from "zod";
import { Upload, FileText, Calculator } from "lucide-react";

const expenseFormSchema = insertExpenseSchema.omit({
  employeeId: true,
  submittedBy: true,
  employeeName: true,
  employeeEmail: true,
  department: true,
}).extend({
  amount: z.string().optional(),
  expenseDate: z.string().min(1, "Date is required"),
  mileageDistance: z.string().optional(),
  mileageStartLocation: z.string().optional(),
  mileageEndLocation: z.string().optional(),
});

type ExpenseFormData = z.infer<typeof expenseFormSchema>;

interface ExpenseFormModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ExpenseFormModal({ isOpen, onClose }: ExpenseFormModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState("regular");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch mileage rate
  const { data: mileageRateData } = useQuery({
    queryKey: ["/api/mileage-rate"],
    enabled: isOpen && activeTab === "mileage",
  });

  const form = useForm<ExpenseFormData>({
    resolver: zodResolver(expenseFormSchema),
    defaultValues: {
      amount: "",
      description: "",
      category: "Other",
      expenseDate: new Date().toISOString().split('T')[0],
      receiptUrl: "",
      receiptFileName: "",
      mileageDistance: "",
      mileageStartLocation: "",
      mileageEndLocation: "",
    },
  });

  // File handling functions
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Enhanced file type validation
      const allowedTypes = [
        "application/pdf",
        "image/jpeg",
        "image/jpg", 
        "image/png",
        "image/webp",
        "image/gif"
      ];
      
      if (allowedTypes.includes(file.type)) {
        if (file.size <= 5 * 1024 * 1024) { // 5MB limit
          setSelectedFile(file);
          form.setValue("receiptFileName", file.name);
          toast({
            title: "File uploaded successfully",
            description: `${file.name} (${(file.size / 1024 / 1024).toFixed(2)}MB)`,
          });
        } else {
          toast({
            title: "File too large",
            description: `File is ${(file.size / 1024 / 1024).toFixed(2)}MB. Please select a file smaller than 5MB.`,
            variant: "destructive",
          });
        }
      } else {
        toast({
          title: "Invalid file type",
          description: "Please select a PDF, JPG, PNG, WebP, or GIF file",
          variant: "destructive",
        });
      }
    }
  };

  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        resolve(result.split(',')[1]); // Remove data URL prefix
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  // Calculate mileage amount
  const calculateMileageAmount = () => {
    const distance = parseFloat(form.watch("mileageDistance") || "0");
    const rate = (mileageRateData as any)?.rate || 0.68;
    return distance * rate;
  };

  const createExpenseMutation = useMutation({
    mutationFn: async (data: ExpenseFormData) => {
      const authHeaders = getAuthHeader();
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      
      if (authHeaders.Authorization) {
        headers.Authorization = authHeaders.Authorization;
      }

      let submissionData = { ...data };

      // Handle file upload
      if (selectedFile) {
        const fileData = await convertFileToBase64(selectedFile);
        submissionData.receiptFileData = fileData;
        submissionData.receiptFileType = selectedFile.type;
      }

      // Handle mileage calculation
      if (activeTab === "mileage" && data.mileageDistance) {
        const calculatedAmount = calculateMileageAmount();
        submissionData.amount = calculatedAmount.toFixed(2);
        submissionData.mileageRate = ((mileageRateData as any)?.rate || 0.68).toString();
      }
      
      const response = await fetch("/api/expenses", {
        method: "POST",
        headers,
        body: JSON.stringify(submissionData),
      });
      if (!response.ok) {
        const errorData = await response.text();
        console.error("Expense creation failed:", response.status, errorData);
        throw new Error(`Failed to create expense: ${response.status} ${errorData}`);
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/expenses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Success",
        description: "Expense submitted successfully",
      });
      form.reset();
      onClose();
    },
    onError: (error) => {
      console.error("Expense submission error:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to submit expense",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: ExpenseFormData) => {
    setIsSubmitting(true);
    try {
      // Enhanced validation for different expense types
      if (activeTab === "mileage") {
        if (!data.mileageDistance || parseFloat(data.mileageDistance) <= 0) {
          toast({
            title: "Invalid distance",
            description: "Please enter a valid distance greater than 0",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
        if (!data.mileageStartLocation || !data.mileageEndLocation) {
          toast({
            title: "Missing locations",
            description: "Please specify both start and end locations",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
        if (!data.description || data.description.trim().length < 10) {
          toast({
            title: "Business purpose required",
            description: "Please provide a detailed business purpose (at least 10 characters)",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
      } else {
        if (!data.amount || parseFloat(data.amount) <= 0) {
          toast({
            title: "Invalid amount",
            description: "Please enter a valid amount greater than $0.00",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
        if (!data.description || data.description.trim().length < 5) {
          toast({
            title: "Description required",
            description: "Please provide a description (at least 5 characters)",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
      }
      
      await createExpenseMutation.mutateAsync(data);
    } finally {
      setIsSubmitting(false);
    }
  };

  const categories = [
    "Meals & Entertainment",
    "Transportation",
    "Lodging", 
    "Travel",
    "Office Supplies",
    "Equipment",
    "Software",
    "Training",
    "Conference & Events",
    "Client Entertainment",
    "Marketing",
    "Internet & Phone",
    "Parking & Tolls",
    "Fuel",
    "Mileage",
    "Other",
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Submit New Expense</DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="regular" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Regular Expense
            </TabsTrigger>
            <TabsTrigger value="mileage" className="flex items-center gap-2">
              <Calculator className="w-4 h-4" />
              Mileage Expense
            </TabsTrigger>
          </TabsList>

          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 mt-6">
            <TabsContent value="regular" className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="amount">Amount ($)</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500">$</span>
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      className="pl-8"
                      {...form.register("amount")}
                    />
                  </div>
                  {form.formState.errors.amount && (
                    <p className="text-sm text-red-600 mt-1">
                      {form.formState.errors.amount.message}
                    </p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="expenseDate">Date</Label>
                  <Input
                    id="expenseDate"
                    type="date"
                    {...form.register("expenseDate")}
                  />
                  {form.formState.errors.expenseDate && (
                    <p className="text-sm text-red-600 mt-1">
                      {form.formState.errors.expenseDate.message}
                    </p>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="e.g., Client dinner at Restaurant ABC, Office supplies for Q1 project, Travel to conference..."
                  rows={3}
                  {...form.register("description")}
                />
                {form.formState.errors.description && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.description.message}
                  </p>
                )}
                <p className="text-xs text-slate-500 mt-1">
                  Be specific about business purpose for faster approval
                </p>
              </div>

              <div>
                <Label htmlFor="category">Category</Label>
                <Select
                  value={form.watch("category")}
                  onValueChange={(value) => form.setValue("category", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.category && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.category.message}
                  </p>
                )}
              </div>

              {/* Receipt Upload Section */}
              <div className="space-y-4">
                <Label>Receipt</Label>
                <div className="space-y-3">
                  <div className="space-y-3">
                    <div className="flex items-center gap-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => fileInputRef.current?.click()}
                        className="flex items-center gap-2 hover:bg-blue-50 hover:border-blue-300"
                      >
                        <Upload className="w-4 h-4" />
                        {selectedFile ? "Change File" : "Upload Receipt"}
                      </Button>
                      {selectedFile && (
                        <div className="flex items-center gap-2 text-sm text-green-600 bg-green-50 px-3 py-1 rounded-full">
                          <FileText className="w-4 h-4" />
                          <span className="font-medium">{selectedFile.name}</span>
                          <span className="text-green-500">
                            ({(selectedFile.size / 1024 / 1024).toFixed(2)}MB)
                          </span>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelectedFile(null);
                              form.setValue("receiptFileName", "");
                              if (fileInputRef.current) fileInputRef.current.value = "";
                            }}
                            className="h-4 w-4 p-0 text-green-600 hover:text-red-600"
                          >
                            ×
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,image/*"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                  <div className="text-xs text-slate-500">
                    Supported: PDF, JPG, PNG, WebP (max 5MB) • Clear, readable receipts process faster
                  </div>
                </div>

                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <span>OR</span>
                  <hr className="flex-1" />
                </div>

                <div>
                  <Label htmlFor="receiptUrl">Receipt URL</Label>
                  <Input
                    id="receiptUrl"
                    type="url"
                    placeholder="https://example.com/receipt.pdf"
                    {...form.register("receiptUrl")}
                  />
                  <p className="text-sm text-slate-500 mt-1">
                    Link to receipt from Google Drive or another service
                  </p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="mileage" className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="mileageDistance">Distance (miles)</Label>
                  <div className="relative">
                    <Input
                      id="mileageDistance"
                      type="number"
                      step="0.1"
                      min="0"
                      max="10000"
                      placeholder="0.0"
                      {...form.register("mileageDistance")}
                    />
                    <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-500 text-sm">miles</span>
                  </div>
                  {form.formState.errors.mileageDistance && (
                    <p className="text-sm text-red-600 mt-1">
                      {form.formState.errors.mileageDistance.message}
                    </p>
                  )}
                  <p className="text-xs text-slate-500 mt-1">Round trip? Include both directions</p>
                </div>
                
                <div>
                  <Label htmlFor="expenseDate">Date</Label>
                  <Input
                    id="expenseDate"
                    type="date"
                    {...form.register("expenseDate")}
                  />
                  {form.formState.errors.expenseDate && (
                    <p className="text-sm text-red-600 mt-1">
                      {form.formState.errors.expenseDate.message}
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="mileageStartLocation">Start Location</Label>
                  <Input
                    id="mileageStartLocation"
                    placeholder="e.g., 123 Main St, Toronto ON or Home Office"
                    {...form.register("mileageStartLocation")}
                  />
                  <p className="text-xs text-slate-500 mt-1">Include city for verification</p>
                </div>
                
                <div>
                  <Label htmlFor="mileageEndLocation">End Location</Label>
                  <Input
                    id="mileageEndLocation"
                    placeholder="e.g., Client ABC Office, 456 Bay St, Toronto"
                    {...form.register("mileageEndLocation")}
                  />
                  <p className="text-xs text-slate-500 mt-1">Be specific for faster approval</p>
                </div>
              </div>

              <div>
                <Label htmlFor="description">Business Purpose</Label>
                <Textarea
                  id="description"
                  placeholder="e.g., Client meeting with XYZ Corp, Delivery to ABC warehouse, Site visit for project assessment..."
                  rows={3}
                  {...form.register("description")}
                />
                {form.formState.errors.description && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.description.message}
                  </p>
                )}
                <p className="text-xs text-slate-500 mt-1">
                  Detail the business reason for this travel
                </p>
              </div>

              {/* Mileage Rate Info */}
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="flex items-center gap-2 text-sm">
                  <Calculator className="w-4 h-4 text-blue-600" />
                  <span className="font-medium text-blue-900 dark:text-blue-100">Mileage Calculation</span>
                </div>
                <div className="mt-3 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-300">Current Rate:</span>
                    <span className="font-medium">${((mileageRateData as any)?.rate || 0.68).toFixed(3)} per mile</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-300">Distance:</span>
                    <span className="font-medium">{form.watch("mileageDistance") || "0"} miles</span>
                  </div>
                  <hr className="border-blue-200 dark:border-blue-700" />
                  <div className="flex justify-between text-base">
                    <span className="font-medium text-blue-900 dark:text-blue-100">Total Amount:</span>
                    <span className="font-bold text-blue-700 dark:text-blue-300 text-lg">
                      ${calculateMileageAmount().toFixed(2)}
                    </span>
                  </div>
                </div>
                <p className="text-xs text-blue-600 dark:text-blue-400 mt-2">
                  Rate updated automatically based on company policy
                </p>
              </div>
            </TabsContent>

            <div className="flex justify-between items-center pt-6 border-t border-slate-200">
              <div className="text-sm text-slate-500">
                {activeTab === "regular" ? (
                  <span>💡 Tip: Include receipts for faster approval</span>
                ) : (
                  <span>🚗 Mileage rate: ${((mileageRateData as any)?.rate || 0.68).toFixed(3)}/mile</span>
                )}
              </div>
              <div className="flex space-x-3">
                <Button type="button" variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={isSubmitting || createExpenseMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700 text-white min-w-[140px]"
                >
                  {isSubmitting || createExpenseMutation.isPending ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Submitting...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Upload className="w-4 h-4" />
                      Submit Expense
                    </div>
                  )}
                </Button>
              </div>
            </div>
          </form>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}