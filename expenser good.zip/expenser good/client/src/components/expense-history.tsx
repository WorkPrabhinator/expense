import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Receipt, Calendar, DollarSign, Eye } from "lucide-react";
import { format } from "date-fns";
import type { Expense } from "@shared/schema";

interface ExpenseHistoryProps {
  userId?: string;
  showAllExpenses?: boolean;
}

export function ExpenseHistory({ userId, showAllExpenses = false }: ExpenseHistoryProps) {
  const { data: expenses, isLoading } = useQuery<Expense[]>({
    queryKey: showAllExpenses ? ["/api/expenses"] : ["/api/expenses/my"],
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-100 text-green-800 border-green-200";
      case "rejected":
        return "bg-red-100 text-red-800 border-red-200";
      case "pending":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const filterExpensesByStatus = (status?: string) => {
    if (!expenses) return [];
    if (!status) return expenses;
    return expenses.filter(expense => expense.status === status);
  };

  const ExpensesList = ({ expenses: filteredExpenses }: { expenses: Expense[] }) => (
    <div className="space-y-3 max-h-96 overflow-y-auto">
      {filteredExpenses.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <Receipt className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p>No expenses found</p>
        </div>
      ) : (
        filteredExpenses.map((expense) => (
          <div
            key={expense.id}
            className="p-4 border rounded-lg bg-white hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <h4 className="font-medium text-gray-900 mb-1">
                  {expense.description}
                </h4>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {format(new Date(expense.expenseDate), "MMM d, yyyy")}
                  </div>
                  <div className="flex items-center gap-1">
                    <DollarSign className="h-3 w-3" />
                    ${parseFloat(expense.amount).toFixed(2)}
                  </div>
                  {expense.category && (
                    <span className="bg-gray-100 px-2 py-1 rounded text-xs">
                      {expense.category}
                    </span>
                  )}
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Badge className={getStatusColor(expense.status)}>
                  {expense.status}
                </Badge>
                <Button size="sm" variant="ghost">
                  <Eye className="h-3 w-3" />
                </Button>
              </div>
            </div>
            
            {showAllExpenses && expense.employeeName && (
              <div className="text-xs text-gray-500 mt-2">
                Submitted by: {expense.employeeName}
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Expense History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            <div className="h-16 bg-gray-200 rounded"></div>
            <div className="h-16 bg-gray-200 rounded"></div>
            <div className="h-16 bg-gray-200 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const allExpenses = filterExpensesByStatus();
  const pendingExpenses = filterExpensesByStatus("pending");
  const approvedExpenses = filterExpensesByStatus("approved");
  const rejectedExpenses = filterExpensesByStatus("rejected");

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Receipt className="h-5 w-5 text-blue-600" />
          {showAllExpenses ? "All Expenses" : "My Expense History"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all" className="text-xs">
              All ({allExpenses.length})
            </TabsTrigger>
            <TabsTrigger value="pending" className="text-xs">
              Pending ({pendingExpenses.length})
            </TabsTrigger>
            <TabsTrigger value="approved" className="text-xs">
              Approved ({approvedExpenses.length})
            </TabsTrigger>
            <TabsTrigger value="rejected" className="text-xs">
              Rejected ({rejectedExpenses.length})
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="mt-4">
            <ExpensesList expenses={allExpenses} />
          </TabsContent>
          
          <TabsContent value="pending" className="mt-4">
            <ExpensesList expenses={pendingExpenses} />
          </TabsContent>
          
          <TabsContent value="approved" className="mt-4">
            <ExpensesList expenses={approvedExpenses} />
          </TabsContent>
          
          <TabsContent value="rejected" className="mt-4">
            <ExpensesList expenses={rejectedExpenses} />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}