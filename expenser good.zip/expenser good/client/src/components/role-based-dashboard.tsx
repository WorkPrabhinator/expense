import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getAuthHeader, useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { SystemStatus } from "./system-status";
import { NotificationsPanel } from "./notifications-panel";
import { useToast } from "@/hooks/use-toast";
import { ExpenseHistory } from "./expense-history";
import { StatsOverview } from "./stats-overview";
import { ExpenseFormModal } from "./expense-form-modal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, 
  Users, 
  User, 
  Plus, 
  FileText, 
  Settings,
  TrendingUp,
  DollarSign,
  Clock,
  CheckCircle,
  Calculator,
  X
} from "lucide-react";

// Admin Expense Section Component
function AdminExpenseSection({ status }: { status: string }) {
  const { data: expenses = [], isLoading } = useQuery({
    queryKey: [`/api/expenses`, { status }],
    queryFn: async () => {
      const authHeaders = getAuthHeader();
      const headers: Record<string, string> = {};
      
      if (authHeaders.Authorization) {
        headers.Authorization = authHeaders.Authorization;
      }
      
      const response = await fetch(`/api/expenses?status=${status}`, {
        headers,
      });
      if (!response.ok) throw new Error("Failed to fetch expenses");
      return response.json();
    },
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status: newStatus, note }: { id: number; status: string; note?: string }) => {
      const authHeaders = getAuthHeader();
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      
      if (authHeaders.Authorization) {
        headers.Authorization = authHeaders.Authorization;
      }
      
      const response = await fetch(`/api/expenses/${id}/status`, {
        method: "PATCH",
        headers,
        body: JSON.stringify({ status: newStatus, approvalNote: note }),
      });
      if (!response.ok) throw new Error("Failed to update expense");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/expenses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/system-status"] });
      toast({
        title: "Success",
        description: "Expense status updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update expense",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return <div className="animate-pulse h-20 bg-gray-200 rounded"></div>;
  }

  const recent = expenses.slice(0, 3);

  return (
    <div className="space-y-3">
      <div className="text-2xl font-bold">{expenses.length}</div>
      {recent.length > 0 ? (
        <div className="space-y-2">
          {recent.map((expense: any) => (
            <div key={expense.id} className="text-xs border-b border-gray-200 pb-2 last:border-b-0">
              <div className="font-medium truncate">{expense.employeeName}</div>
              <div className="text-gray-600">{expense.formattedAmount}</div>
              <div className="truncate text-gray-500">{expense.description}</div>
              {status === "pending" && (
                <div className="flex gap-1 mt-1">
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-6 px-2 text-xs bg-green-50 border-green-200 text-green-700 hover:bg-green-100"
                    onClick={() => updateStatusMutation.mutate({ id: expense.id, status: "approved" })}
                    disabled={updateStatusMutation.isPending}
                  >
                    ✓
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-6 px-2 text-xs bg-red-50 border-red-200 text-red-700 hover:bg-red-100"
                    onClick={() => updateStatusMutation.mutate({ id: expense.id, status: "rejected", note: "Needs review" })}
                    disabled={updateStatusMutation.isPending}
                  >
                    ✗
                  </Button>
                </div>
              )}
            </div>
          ))}
          {expenses.length > 3 && (
            <div className="text-xs text-gray-500">+{expenses.length - 3} more</div>
          )}
        </div>
      ) : (
        <div className="text-xs text-gray-500">No {status} expenses</div>
      )}
    </div>
  );
}

export function RoleBasedDashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [isExpenseFormOpen, setIsExpenseFormOpen] = useState(false);

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-500">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  const getRoleIcon = (role: string) => {
    switch (role) {
      case "admin":
        return <Shield className="h-5 w-5 text-red-600" />;
      case "manager":
        return <Users className="h-5 w-5 text-blue-600" />;
      default:
        return <User className="h-5 w-5 text-gray-600" />;
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "admin":
        return "bg-red-100 text-red-800 border-red-200";
      case "manager":
        return "bg-blue-100 text-blue-800 border-blue-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  // Admin Dashboard Layout
  if (user.role === "admin") {
    return (
      <div className="space-y-6">
        {/* Welcome Header */}
        <div className="bg-gradient-to-r from-red-50 to-red-100 rounded-lg p-6 border border-red-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {getRoleIcon(user.role)}
              <div>
                <h2 className="text-2xl font-bold text-gray-900">
                  Welcome, {user.name}
                </h2>
                <p className="text-gray-600">System Administrator Dashboard</p>
              </div>
            </div>
            <Badge className={getRoleBadgeColor(user.role)}>
              Admin Access
            </Badge>
          </div>
        </div>

        {/* Admin Action Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <CardContent className="p-4 text-center">
              <Settings className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <h3 className="font-semibold text-sm">System Settings</h3>
              <p className="text-xs text-gray-500 mt-1">Configure rates & rules</p>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <CardContent className="p-4 text-center">
              <Users className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <h3 className="font-semibold text-sm">User Management</h3>
              <p className="text-xs text-gray-500 mt-1">Manage team access</p>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <CardContent className="p-4 text-center">
              <FileText className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <h3 className="font-semibold text-sm">All Reports</h3>
              <p className="text-xs text-gray-500 mt-1">View all submissions</p>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <h3 className="font-semibold text-sm">Analytics</h3>
              <p className="text-xs text-gray-500 mt-1">Usage & trends</p>
            </CardContent>
          </Card>
        </div>

        {/* Admin Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <StatsOverview />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Pending Expenses Card */}
              <Card className="border-orange-200 bg-orange-50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-orange-800 flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Pending Review
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <AdminExpenseSection status="pending" />
                </CardContent>
              </Card>
              
              {/* Approved Expenses Card */}
              <Card className="border-green-200 bg-green-50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-green-800 flex items-center gap-2">
                    <CheckCircle className="h-4 w-4" />
                    Approved
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <AdminExpenseSection status="approved" />
                </CardContent>
              </Card>
              
              {/* Rejected Expenses Card */}
              <Card className="border-red-200 bg-red-50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-red-800 flex items-center gap-2">
                    <X className="h-4 w-4" />
                    Rejected
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <AdminExpenseSection status="rejected" />
                </CardContent>
              </Card>
            </div>
          </div>
          <div className="space-y-6">
            <SystemStatus />
            <NotificationsPanel />
          </div>
        </div>
      </div>
    );
  }

  // Manager Dashboard Layout
  if (user.role === "manager") {
    return (
      <div className="space-y-6">
        {/* Welcome Header */}
        <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-6 border border-blue-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {getRoleIcon(user.role)}
              <div>
                <h2 className="text-2xl font-bold text-gray-900">
                  Welcome, {user.name}
                </h2>
                <p className="text-gray-600">Team Manager Dashboard</p>
              </div>
            </div>
            <Badge className={getRoleBadgeColor(user.role)}>
              Manager Access
            </Badge>
          </div>
        </div>

        {/* Manager Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Clock className="h-8 w-8 text-yellow-600" />
                <div>
                  <p className="text-sm text-gray-500">Pending Review</p>
                  <p className="text-2xl font-bold">12</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <CheckCircle className="h-8 w-8 text-green-600" />
                <div>
                  <p className="text-sm text-gray-500">Approved Today</p>
                  <p className="text-2xl font-bold">8</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <DollarSign className="h-8 w-8 text-blue-600" />
                <div>
                  <p className="text-sm text-gray-500">This Month</p>
                  <p className="text-2xl font-bold">$4,235</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Users className="h-8 w-8 text-purple-600" />
                <div>
                  <p className="text-sm text-gray-500">Team Members</p>
                  <p className="text-2xl font-bold">15</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Manager Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <ExpenseHistory showAllExpenses={true} />
          </div>
          <div className="space-y-6">
            <NotificationsPanel />
          </div>
        </div>
      </div>
    );
  }

  // Employee Dashboard Layout (Default)
  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg p-6 border border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {getRoleIcon(user.role)}
            <div>
              <h2 className="text-2xl font-bold text-gray-900">
                Welcome, {user.name}
              </h2>
              <p className="text-gray-600">Employee Dashboard</p>
            </div>
          </div>
          <Badge className={getRoleBadgeColor(user.role)}>
            Employee
          </Badge>
        </div>
      </div>

      {/* Employee Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="hover:shadow-lg transition-all cursor-pointer border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100">
          <CardContent className="p-6 text-center">
            <div className="bg-blue-600 rounded-full p-3 w-16 h-16 mx-auto mb-3 flex items-center justify-center">
              <Plus className="h-8 w-8 text-white" />
            </div>
            <h3 className="font-bold mb-2 text-lg">Submit New Expense</h3>
            <p className="text-sm text-gray-600 mb-4">Upload receipts, track mileage, and submit expenses for approval</p>
            <div className="space-y-2">
              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700"
                onClick={() => setIsExpenseFormOpen(true)}
              >
                <FileText className="w-4 h-4 mr-2" />
                Regular Expense
              </Button>
              <Button 
                variant="outline" 
                className="w-full border-blue-300 text-blue-600 hover:bg-blue-50"
                onClick={() => setIsExpenseFormOpen(true)}
              >
                <Calculator className="w-4 h-4 mr-2" />
                Mileage Expense
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-md transition-shadow cursor-pointer">
          <CardContent className="p-6 text-center">
            <FileText className="h-10 w-10 text-green-600 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">My Submissions</h3>
            <p className="text-sm text-gray-500 mb-4">Track the status of your expense reports</p>
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => setLocation("/my-submissions")}
            >
              View All
            </Button>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-md transition-shadow cursor-pointer">
          <CardContent className="p-6 text-center">
            <TrendingUp className="h-10 w-10 text-purple-600 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Monthly Summary</h3>
            <p className="text-sm text-gray-500 mb-4">View your expense history and trends</p>
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => setLocation("/reports")}
            >
              View Report
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Employee Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ExpenseHistory />
        </div>
        <div>
          <NotificationsPanel />
        </div>
      </div>

      {/* Expense Form Modal */}
      <ExpenseFormModal
        isOpen={isExpenseFormOpen}
        onClose={() => setIsExpenseFormOpen(false)}
      />
    </div>
  );
}