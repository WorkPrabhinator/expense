import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Database, Mail, FileSpreadsheet, AlertCircle, CheckCircle } from "lucide-react";

interface SystemStatus {
  database: "connected" | "disconnected" | "error";
  gmail: "connected" | "disconnected" | "error";
  sheets: "connected" | "disconnected" | "error";
  lastSync: string;
  totalExpenses: number;
  pendingApprovals: number;
}

export function SystemStatus() {
  const { data: status, isLoading } = useQuery<SystemStatus>({
    queryKey: ["/api/admin/system-status"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "connected":
        return "bg-green-100 text-green-800 border-green-200";
      case "disconnected":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "error":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "connected":
        return <CheckCircle className="h-4 w-4" />;
      case "disconnected":
      case "error":
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <AlertCircle className="h-4 w-4" />;
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold">System Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Database className="h-5 w-5 text-blue-600" />
          System Status
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Database className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium">Database</span>
            </div>
            <Badge className={getStatusColor(status?.database || "disconnected")}>
              {getStatusIcon(status?.database || "disconnected")}
              <span className="ml-1 capitalize">{status?.database || "Unknown"}</span>
            </Badge>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium">Gmail API</span>
            </div>
            <Badge className={getStatusColor(status?.gmail || "disconnected")}>
              {getStatusIcon(status?.gmail || "disconnected")}
              <span className="ml-1 capitalize">{status?.gmail || "Unknown"}</span>
            </Badge>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium">Google Sheets</span>
            </div>
            <Badge className={getStatusColor(status?.sheets || "disconnected")}>
              {getStatusIcon(status?.sheets || "disconnected")}
              <span className="ml-1 capitalize">{status?.sheets || "Unknown"}</span>
            </Badge>
          </div>
        </div>

        <div className="pt-3 border-t">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-500">Last Sync</p>
              <p className="font-medium">{status?.lastSync || "Never"}</p>
            </div>
            <div>
              <p className="text-gray-500">Pending Approvals</p>
              <p className="font-medium">{status?.pendingApprovals || 0}</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}