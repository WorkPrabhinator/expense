import { AppHeader } from "@/components/app-header";
import { RoleBasedDashboard } from "@/components/role-based-dashboard";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <RoleBasedDashboard />
      </div>
    </div>
  );
}
