import { AppHeader } from "@/components/app-header";
import { ExpenseList } from "@/components/expense-list";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";

export default function MySubmissions() {
  const { user } = useAuth();
  
  const { data: expenses, isLoading } = useQuery({
    queryKey: ['/api/expenses', 'my-submissions'],
    queryFn: async () => {
      const response = await fetch('/api/expenses', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth-token')}`
        }
      });
      if (!response.ok) throw new Error('Failed to fetch expenses');
      return response.json();
    }
  });

  const myExpenses = expenses?.filter((expense: any) => expense.submittedBy === user?.id) || [];
  
  const stats = {
    total: myExpenses.length,
    pending: myExpenses.filter((e: any) => e.status === 'pending').length,
    approved: myExpenses.filter((e: any) => e.status === 'approved').length,
    rejected: myExpenses.filter((e: any) => e.status === 'rejected').length,
    totalAmount: myExpenses.reduce((sum: number, e: any) => sum + parseFloat(e.amount), 0)
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-900 mb-2">My Submissions</h1>
          <p className="text-slate-600">Track and manage your expense submissions</p>
        </div>

        {/* My Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Total Submitted</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900">{stats.total}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Pending</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Approved</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.approved}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Rejected</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{stats.rejected}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Total Amount</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900">${stats.totalAmount.toFixed(2)}</div>
            </CardContent>
          </Card>
        </div>

        {/* Expense List filtered for current user */}
        <Card>
          <CardHeader>
            <CardTitle>Your Expenses</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">Loading your submissions...</div>
            ) : myExpenses.length > 0 ? (
              <ExpenseList userFilter={user?.id} />
            ) : (
              <div className="text-center py-12 text-slate-500">
                <div className="flex flex-col items-center">
                  <div className="text-4xl mb-4">📄</div>
                  <h3 className="text-lg font-medium text-slate-700 mb-2">You haven't submitted an expense!</h3>
                  <p className="text-slate-500">Submit your first expense to get started tracking your submissions.</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}