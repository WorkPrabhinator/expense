import { AppHeader } from "@/components/app-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";
import { Download, TrendingUp, Calendar, DollarSign } from "lucide-react";
import { useState } from "react";

export default function Reports() {
  const { user } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  
  const { data: expenses, isLoading } = useQuery({
    queryKey: ['/api/expenses'],
    queryFn: async () => {
      const response = await fetch('/api/expenses', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth-token')}`
        }
      });
      if (!response.ok) throw new Error('Failed to fetch expenses');
      return response.json();
    }
  });

  const { data: users } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const response = await fetch('/api/users', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth-token')}`
        }
      });
      if (!response.ok) return [];
      return response.json();
    }
  });

  if (!expenses || isLoading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <AppHeader />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center py-8">Loading reports...</div>
        </div>
      </div>
    );
  }

  // Filter expenses based on selected criteria
  const filteredExpenses = expenses.filter((expense: any) => {
    if (selectedStatus !== "all" && expense.status !== selectedStatus) return false;
    // Add date filtering logic here if needed
    return true;
  });

  // Calculate statistics
  const stats = {
    totalExpenses: filteredExpenses.length,
    totalAmount: filteredExpenses.reduce((sum: number, e: any) => sum + parseFloat(e.amount), 0),
    pendingAmount: filteredExpenses.filter((e: any) => e.status === 'pending').reduce((sum: number, e: any) => sum + parseFloat(e.amount), 0),
    approvedAmount: filteredExpenses.filter((e: any) => e.status === 'approved').reduce((sum: number, e: any) => sum + parseFloat(e.amount), 0),
    averageExpense: filteredExpenses.length > 0 ? filteredExpenses.reduce((sum: number, e: any) => sum + parseFloat(e.amount), 0) / filteredExpenses.length : 0
  };

  // Group by category
  const categoryBreakdown = filteredExpenses.reduce((acc: any, expense: any) => {
    acc[expense.category] = (acc[expense.category] || 0) + parseFloat(expense.amount);
    return acc;
  }, {});

  // Group by user (if admin/approver)
  const userBreakdown = filteredExpenses.reduce((acc: any, expense: any) => {
    const user = users?.find((u: any) => u.id === expense.submittedBy);
    const userName = user ? user.name : 'Unknown User';
    acc[userName] = (acc[userName] || 0) + parseFloat(expense.amount);
    return acc;
  }, {});

  const exportToCSV = () => {
    const headers = ['Date', 'Description', 'Category', 'Amount', 'Status', 'Submitted By'];
    const csvData = [
      headers.join(','),
      ...filteredExpenses.map((expense: any) => {
        const user = users?.find((u: any) => u.id === expense.submittedBy);
        return [
          expense.expenseDate,
          `"${expense.description}"`,
          expense.category,
          expense.amount,
          expense.status,
          user?.name || 'Unknown'
        ].join(',');
      })
    ].join('\n');

    const blob = new Blob([csvData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `expense-report-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-slate-900 mb-2">Reports</h1>
              <p className="text-slate-600">Analyze expense data and export reports</p>
            </div>
            <Button onClick={exportToCSV} className="flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export CSV
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-slate-700 mb-2 block">Time Period</label>
                <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Time</SelectItem>
                    <SelectItem value="thisMonth">This Month</SelectItem>
                    <SelectItem value="lastMonth">Last Month</SelectItem>
                    <SelectItem value="thisYear">This Year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium text-slate-700 mb-2 block">Status</label>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Check if no expenses exist */}
        {filteredExpenses.length === 0 ? (
          <Card className="mb-8">
            <CardContent className="text-center py-12">
              <div className="flex flex-col items-center">
                <div className="text-4xl mb-4">📊</div>
                <h3 className="text-lg font-medium text-slate-700 mb-2">You haven't submitted an expense!</h3>
                <p className="text-slate-500">No expense data available to generate reports. Submit some expenses first.</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Summary Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Total Expenses
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900">{stats.totalExpenses}</div>
            </CardContent>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Total Amount
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900">${stats.totalAmount.toFixed(2)}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Average Expense</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900">${stats.averageExpense.toFixed(2)}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Pending Amount</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">${stats.pendingAmount.toFixed(2)}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Category Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Expenses by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(categoryBreakdown).length > 0 ? (
                  Object.entries(categoryBreakdown).map(([category, amount]: [string, any]) => (
                    <div key={category} className="flex justify-between items-center">
                      <span className="text-slate-700">{category}</span>
                      <span className="font-semibold">${amount.toFixed(2)}</span>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-4 text-slate-500">No category data available</div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* User Breakdown */}
          {(user?.role === 'admin' || user?.role === 'manager') && (
            <Card>
              <CardHeader>
                <CardTitle>Expenses by User</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(userBreakdown).length > 0 ? (
                    Object.entries(userBreakdown).map(([userName, amount]: [string, any]) => (
                      <div key={userName} className="flex justify-between items-center">
                        <span className="text-slate-700">{userName}</span>
                        <span className="font-semibold">${amount.toFixed(2)}</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-4 text-slate-500">No user data available</div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
        </>
        )}
      </div>
    </div>
  );
}