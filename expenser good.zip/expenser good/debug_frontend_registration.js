// Script to test frontend registration exactly as the browser would
const testFrontendRegistration = async () => {
  console.log('=== Frontend Registration Debug Test ===');
  
  try {
    console.log('1. Testing frontend registration with detailed logging...');
    
    const testData = {
      email: 'frontend.debug@example.com',
      name: 'Frontend Debug User',
      department: 'Testing'
    };
    
    console.log('2. Making fetch request to /api/auth/register...');
    console.log('Request data:', testData);
    
    const response = await fetch('http://localhost:5000/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(testData),
    });

    console.log('3. Response status:', response.status);
    console.log('4. Response headers:', Object.fromEntries(response.headers.entries()));
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('5. ERROR Response body:', errorText);
      
      try {
        const errorJson = JSON.parse(errorText);
        console.error('6. Parsed error:', errorJson);
      } catch {
        console.error('6. Could not parse error as JSON');
      }
      
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const data = await response.json();
    console.log('5. SUCCESS Response data:', data);
    
    // Test duplicate registration
    console.log('\n=== Testing Duplicate Registration ===');
    const duplicateResponse = await fetch('http://localhost:5000/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(testData),
    });
    
    console.log('Duplicate response status:', duplicateResponse.status);
    const duplicateText = await duplicateResponse.text();
    console.log('Duplicate response body:', duplicateText);
    
  } catch (error) {
    console.error('Frontend registration test failed:', error.message);
    console.error('Full error:', error);
  }
};

// Check if we're in Node.js environment
if (typeof fetch === 'undefined') {
  // Import fetch for Node.js
  import('node-fetch').then(({ default: fetch }) => {
    global.fetch = fetch;
    testFrontendRegistration();
  }).catch(() => {
    console.error('node-fetch not available, testing via curl instead...');
  });
} else {
  // Browser environment
  testFrontendRegistration();
}