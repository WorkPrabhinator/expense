CREATE TABLE "expenses" (
	"id" serial PRIMARY KEY NOT NULL,
	"employee_id" integer NOT NULL,
	"employee_name" text NOT NULL,
	"employee_email" text NOT NULL,
	"department" text,
	"amount" numeric(10, 2) NOT NULL,
	"description" text NOT NULL,
	"category" text NOT NULL,
	"expense_date" timestamp NOT NULL,
	"submission_date" timestamp DEFAULT now() NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"approved_by" integer,
	"approved_by_name" text,
	"approval_date" timestamp,
	"approval_note" text,
	"receipt_url" text,
	"receipt_file_name" text,
	"receipt_file_data" text,
	"receipt_file_type" text,
	"mileage_distance" numeric(8, 2),
	"mileage_rate" numeric(5, 3),
	"mileage_start_location" text,
	"mileage_end_location" text,
	"email_id" text,
	"form_submission_id" text,
	"sheets_row_number" integer,
	"notification_sent" boolean DEFAULT false NOT NULL
);
--> statement-breakpoint
CREATE TABLE "system_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"key" text NOT NULL,
	"value" text NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "system_settings_key_unique" UNIQUE("key")
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"email" text NOT NULL,
	"name" text NOT NULL,
	"department" text,
	"role" text DEFAULT 'employee' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "users_email_unique" UNIQUE("email")
);
