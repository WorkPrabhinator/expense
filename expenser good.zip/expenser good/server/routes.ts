import type { Express } from "express";
import { driveService } from './services/drive';
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { gmailService } from "./services/gmail";
import { sheetsService } from "./services/sheets";
import { notificationService } from "./services/notifications";
import { insertExpenseSchema, updateExpenseStatusSchema, users } from "@shared/schema";
import { z } from "zod";

// Simple session storage for demo purposes
const sessions = new Map<string, { userId: number; email: string; createdAt: Date }>();

// Middleware to check authentication
function requireAuth(req: any, res: any, next: any) {
  const sessionId = req.headers.authorization?.replace('Bearer ', '');
  const session = sessionId ? sessions.get(sessionId) : null;
  
  if (!session) {
    return res.status(401).json({ message: "Authentication required" });
  }
  
  req.user = session;
  next();
}

// Simple login endpoint
async function handleLogin(req: any, res: any) {
  try {
    const { email } = req.body;
    console.log('Login attempt for email:', email);
    const user = await storage.getUserByEmail(email);
    console.log('getUserByEmail returned:', user ? `User ID ${users.id}` : 'null/undefined');
    
    if (!user) {
      console.log('Login failed: User not found for email:', email);
      return res.status(401).json({ message: "User not found" });
    }
    
    // Generate simple session token
    const sessionId = Math.random().toString(36).substring(2, 15);
    sessions.set(sessionId, { userId: user.id, email: user.email, createdAt: new Date() });
    
    res.json({ 
      token: sessionId, 
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        department: user.department,
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: "Login failed" });
  }
}

async function handleRegister(req: any, res: any) {
  try {
    console.log('Registration request received:', { body: req.body });
    const { email, name, department } = req.body;
    
    if (!email || !name) {
      console.log('Validation failed: missing email or name');
      return res.status(400).json({ message: "Email and name are required" });
    }
    
    // Check if user already exists
    console.log('Checking for existing user with email:', email);
    const existingUser = await storage.getUserByEmail(email);
    if (existingUser) {
      console.log('User already exists:', existingUser.id);
      return res.status(409).json({ message: "User already exists with this email" });
    }
    
    // Create new user (default role is 'employee')
    const normalizedEmail = email.trim().toLowerCase();
    console.log('Creating new user:', { email: normalizedEmail, name, department });
    const userData = {
      email: normalizedEmail,  // Use normalized email
      name: name.trim(),       // Also trim name
      role: 'employee' as const,
      department: department ? department.trim() : null,
      isActive: true,
    };
    console.log('User data to create:', userData);
    
    const newUser = await storage.createUser(userData);
    console.log('User created successfully:', newUser.id);
    
    // Create session
    const sessionId = Math.random().toString(36).substring(2, 15);
    sessions.set(sessionId, { userId: newUser.id, email: newUser.email, createdAt: new Date() });
    console.log('Session created:', sessionId);
    
    const response = { 
      token: sessionId, 
      user: {
        id: newUser.id,
        email: newUser.email,
        name: newUser.name,
        role: newUser.role,
        department: newUser.department,
      }
    };
    console.log('✅ storage.createUser() SUCCESS: Created user ID', newUser.id);
    res.json(response);
  } catch (error) {
    console.error('Registration error details:', error);
    if (error instanceof Error) {
      console.error('Error message:', error.message);
      console.error('Error stack:', error.stack);
    }
    res.status(500).json({ message: "Registration failed", error: error instanceof Error ? error.message : String(error) });
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/login", handleLogin);
  app.post("/api/auth/register", handleRegister);
  
  app.get("/api/auth/me", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        department: user.department,
      });
    } catch (error) {
      console.error('Get user error:', error);
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  // Expense routes
  app.get("/api/expenses", requireAuth, async (req: any, res) => {
    try {
      const { status, employee } = req.query;
      let expenses;
      
      if (status) {
        expenses = await storage.getExpensesByStatus(status as string);
      } else if (employee && req.user.userId.toString() === employee) {
        expenses = await storage.getExpensesByEmployee(parseInt(employee));
      } else {
        expenses = await storage.getAllExpenses();
      }
      
      // Format expenses for frontend
      const formattedExpenses = expenses.map(expense => ({
        ...expense,
        formattedAmount: `$${parseFloat(expense.amount).toFixed(2)}`,
        formattedDate: expense.expenseDate.toISOString().split('T')[0],
        initials: expense.employeeName.split(' ').map(n => n[0]).join('').toUpperCase(),
      }));
      
      res.json(formattedExpenses);
    } catch (error) {
      console.error('Get expenses error:', error);
      res.status(500).json({ message: "Failed to get expenses" });
    }
  });

  app.get("/api/expenses/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const expense = await storage.getExpense(id);
      
      if (!expense) {
        return res.status(404).json({ message: "Expense not found" });
      }
      
      res.json({
        ...expense,
        formattedAmount: `$${parseFloat(expense.amount).toFixed(2)}`,
        formattedDate: expense.expenseDate.toISOString().split('T')[0],
        initials: expense.employeeName.split(' ').map(n => n[0]).join('').toUpperCase(),
      });
    } catch (error) {
      console.error('Get expense error:', error);
      res.status(500).json({ message: "Failed to get expense" });
    }
  });

  app.post("/api/expenses", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Handle mileage calculations
      let calculatedAmount = req.body.amount;
      if (req.body.mileageDistance && req.body.mileageRate) {
        const distance = parseFloat(req.body.mileageDistance);
        const rate = parseFloat(req.body.mileageRate);
        calculatedAmount = (distance * rate).toFixed(2);
      }

      let receiptUrl = req.body.receiptUrl || "";
      if (req.body.receiptFileData && req.body.receiptFileType && req.body.receiptFileName) {
        try {
          const buffer = Buffer.from(req.body.receiptFileData, 'base64');
          receiptUrl = await driveService.uploadReceipt(
            req.body.receiptFileName,
            req.body.receiptFileType,
            buffer
          );
        } catch (error) {
          console.error('Failed to upload receipt to Drive:', error);
          // Continue without receipt upload - store file data in database instead
          receiptUrl = "";
        }
      }

      const expenseData = insertExpenseSchema.parse({
        ...req.body,
        amount: calculatedAmount,
        employeeId: user.id,
        submittedBy: user.id,
        employeeName: user.name,
        employeeEmail: user.email,
        department: user.department,
        receiptUrl,
      });
      
      const expense = await storage.createExpense(expenseData);
      
      // Add to Google Sheets (optional service)
      try {
        await sheetsService.addExpense(expense);
      } catch (error: any) {
        console.warn('Google Sheets integration not configured:', error?.message || error);
      }
      
      // Send notification to approvers (optional service)
      try {
        await notificationService.sendExpenseSubmissionNotification(expense);
      } catch (error: any) {
        console.warn('Email notifications not configured:', error?.message || error);
      }
      
      res.status(201).json(expense);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error('Create expense error:', error);
      res.status(500).json({ message: "Failed to create expense" });
    }
  });

  app.patch("/api/expenses/:id/status", requireAuth, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(req.user.userId);
      
      if (!user || (user.role !== 'approver' && user.role !== 'admin')) {
        return res.status(403).json({ message: "Insufficient permissions" });
      }
      
      const updateData = updateExpenseStatusSchema.parse({
        ...req.body,
        approvedBy: user.id,
        approvedByName: user.name,
      });
      
      const expense = await storage.updateExpenseStatus(id, updateData);
      
      if (!expense) {
        return res.status(404).json({ message: "Expense not found" });
      }
      
      // Update Google Sheets
      try {
        await sheetsService.updateExpenseStatus(expense);
      } catch (error) {
        console.error('Failed to update sheets:', error);
      }
      
      // Send notification to employee
      try {
        await notificationService.sendApprovalNotification(expense);
      } catch (error) {
        console.error('Failed to send notification:', error);
      }
      
      res.json(expense);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error('Update expense status error:', error);
      res.status(500).json({ message: "Failed to update expense status" });
    }
  });

  // Stats endpoint
  app.get("/api/stats", requireAuth, async (req, res) => {
    try {
      const stats = await storage.getExpenseStats();
      res.json({
        ...stats,
        totalAmount: `$${stats.totalAmount.toFixed(2)}`,
      });
    } catch (error) {
      console.error('Get stats error:', error);
      res.status(500).json({ message: "Failed to get stats" });
    }
  });

  // Mileage rate endpoints
  app.get("/api/mileage-rate", requireAuth, async (req, res) => {
    try {
      const rateSetting = await storage.getSetting("mileage_rate");
      const rate = rateSetting ? parseFloat(rateSetting.value) : 0.68; // Default Canadian rate
      res.json({ rate });
    } catch (error) {
      console.error('Get mileage rate error:', error);
      res.status(500).json({ message: "Failed to get mileage rate" });
    }
  });

  // Admin system status endpoint
  app.get("/api/admin/system-status", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      // Get expense statistics
      const stats = await storage.getExpenseStats();
      const pendingExpenses = await storage.getExpensesByStatus('pending');
      
      // Check system component status
      const systemStatus = {
        database: "connected", // Always connected if we can query
        gmail: process.env.GOOGLE_CLIENT_EMAIL ? "connected" : "disconnected",
        sheets: process.env.GOOGLE_SHEETS_ID ? "connected" : "disconnected",
        lastSync: new Date().toISOString(),
        totalExpenses: stats.totalExpenses || 0,
        pendingApprovals: pendingExpenses.length,
      };

      res.json(systemStatus);
    } catch (error) {
      console.error('Get system status error:', error);
      res.status(500).json({ message: "Failed to get system status" });
    }
  });

  app.post("/api/mileage-rate", requireAuth, async (req, res) => {
    try {
      const { rate } = req.body;
      
      if (!rate || isNaN(parseFloat(rate))) {
        return res.status(400).json({ message: "Valid rate is required" });
      }
      
      await storage.setSetting({ key: "mileage_rate", value: rate.toString() });
      res.json({ rate: parseFloat(rate) });
    } catch (error) {
      console.error('Set mileage rate error:', error);
      res.status(500).json({ message: "Failed to set mileage rate" });
    }
  });

  // Background job endpoints (for testing)
  app.post("/api/admin/sync-emails", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      await gmailService.checkForNewExpenseEmails();
      res.json({ message: "Email sync completed" });
    } catch (error) {
      console.error('Email sync error:', error);
      res.status(500).json({ message: "Email sync failed" });
    }
  });

  app.post("/api/admin/sync-sheets", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      await sheetsService.syncExpensesToSheet();
      res.json({ message: "Sheets sync completed" });
    } catch (error) {
      console.error('Sheets sync error:', error);
      res.status(500).json({ message: "Sheets sync failed" });
    }
  });

  // System status endpoint for admin dashboard
  app.get("/api/admin/system-status", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      // Check database connection
      let dbStatus = "connected";
      try {
        await storage.getExpenseStats();
      } catch (error) {
        dbStatus = "error";
      }

      // Get system stats
      const stats = await storage.getExpenseStats();
      const pendingCount = await storage.getAllExpenses()
        .then((expenses: any[]) => expenses.filter((e: any) => e.status === 'pending').length)
        .catch(() => 0);

      const systemStatus = {
        database: dbStatus,
        gmail: "connected", // This would check actual Gmail API status
        sheets: "connected", // This would check actual Sheets API status
        lastSync: new Date().toISOString(),
        totalExpenses: stats.totalExpenses,
        pendingApprovals: pendingCount
      };

      res.json(systemStatus);
    } catch (error) {
      console.error('System status error:', error);
      res.status(500).json({ message: "Failed to get system status" });
    }
  });

  // Notifications endpoint
  app.get("/api/notifications", requireAuth, async (req: any, res) => {
    try {
      // Mock notifications - in real app, this would come from database
      const notifications = [
        {
          id: "1",
          title: "New Expense Submitted",
          message: "John Doe submitted a $125.50 meal expense for review",
          priority: "medium",
          type: "info",
          createdAt: new Date().toISOString(),
          actionRequired: true,
          actionUrl: "/expenses/123"
        },
        {
          id: "2", 
          title: "Monthly Report Ready",
          message: "December expense report is ready for download",
          priority: "low",
          type: "success",
          createdAt: new Date(Date.now() - 3600000).toISOString(),
          actionRequired: false
        }
      ];

      res.json(notifications);
    } catch (error) {
      console.error('Notifications error:', error);
      res.status(500).json({ message: "Failed to get notifications" });
    }
  });

  // Profile endpoint with enhanced user data
  app.get("/api/profile", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Get user's expense statistics
      const userExpenses = await storage.getAllExpenses()
        .then((expenses: any[]) => expenses.filter((e: any) => e.employeeEmail === user.email))
        .catch(() => []);

      const stats = {
        totalSubmitted: userExpenses.length,
        totalAmount: userExpenses.reduce((sum: number, e: any) => sum + parseFloat(e.amount), 0),
        pending: userExpenses.filter((e: any) => e.status === 'pending').length,
        approved: userExpenses.filter((e: any) => e.status === 'approved').length,
        rejected: userExpenses.filter((e: any) => e.status === 'rejected').length
      };

      res.json({
        ...user,
        stats
      });
    } catch (error) {
      console.error('Profile error:', error);
      res.status(500).json({ message: "Failed to get profile" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}